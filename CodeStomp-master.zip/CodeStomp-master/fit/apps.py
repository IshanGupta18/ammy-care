from django.apps import AppConfig


class FitConfig(AppConfig):
    name = 'fit'
